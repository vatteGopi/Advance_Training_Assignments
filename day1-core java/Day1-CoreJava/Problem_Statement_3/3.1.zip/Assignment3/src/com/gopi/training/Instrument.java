package com.gopi.training;

public abstract class Instrument {
	public abstract void play();
}
